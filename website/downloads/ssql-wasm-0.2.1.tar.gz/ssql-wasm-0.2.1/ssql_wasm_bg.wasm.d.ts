/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const compile_ssql_wasm: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
export const format_ssql_wasm: (a: number, b: number, c: number) => void;
export const lint_ssql_wasm: (a: number, b: number, c: number) => void;
export const transpile_sql_to_ssql_wasm: (a: number, b: number, c: number, d: number, e: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_export: (a: number, b: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export3: (a: number, b: number, c: number) => void;
